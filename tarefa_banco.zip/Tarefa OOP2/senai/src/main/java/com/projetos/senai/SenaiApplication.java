package com.projetos.senai;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenaiApplication.class, args);
		ArrayList<Cliente> clientes = new ArrayList<>();
		String logon = "1";
		int escolha;
		int index_conta = 0;

		try (ObjectInputStream lista = new ObjectInputStream(new FileInputStream("clientes.dat"))) {
            clientes = (ArrayList<Cliente>) lista.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
		Menu menu = new Menu();
		while (logon == "1"){
			logon = menu.welcome(clientes);
		}
		escolha = menu.mensagens();
		// instanciar um cliente oriundo do arquivo .dat
		//Cliente novo = new Cliente();
		//novo.add_cliente(clientes, menu.frases);

		for (int i = 0; i < clientes.size(); i++){
			if(clientes.get(i).getLogin() == logon){
				index_conta = i;
				break;
			}
		}
		switch (escolha){
			case 1:
				clientes.get(index_conta).ver_saldo(clientes,menu.frases);
				break;
			case 2:
				clientes.get(index_conta).depositar(clientes, menu.frases);
				break;
			case 3:
				clientes.get(index_conta).sacar(clientes, menu.frases); 
				break;
			//case 4:
			// alterar infos com get e set 
			//case 5 sair
			// limpar o while ?
			default :
				System.out.println("Erro");
		}	
}
}
