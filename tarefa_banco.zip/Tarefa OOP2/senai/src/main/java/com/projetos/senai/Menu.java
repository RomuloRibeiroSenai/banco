package com.projetos.senai;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    String frases[] =
    {"Bem vindo", "Selecione a operação", "Saldo",
    "Depositar", "Sacar", "Alterar informações",
    "Login: ", "Senha: ", "Login Errado", "Senha Errada",
    "Selecione o valor: ","Valor inválido","Bem sucedido",
    "Seu novo ","Acessar Conta", "Criar conta"};

    Scanner sc = new Scanner(System.in);
    
    public String welcome(ArrayList<Cliente> clientes){
        String temp_login;
        int temp_senha;
           
            System.out.println(frases[6]);
            temp_login = sc.nextLine();
            System.out.println(frases[7]);
            temp_senha = sc.nextInt();
            sc.nextLine();

        for (int i = 0; i < clientes.size(); i++){
            if (temp_login.equals(clientes.get(i).getLogin())){
                if (temp_senha == (clientes.get(i).getSenha())){                  
                    return temp_login;
                } else {
                    System.out.println(frases[9]);
                }
            } else {
                System.out.println(frases[8]);
            }
        }        
        return "1";
    }
    public int mensagens(){
        System.out.println("\n" + frases[0] + "\n\n" + frases[1]);
        System.out.println("\n(1)" + frases[2] + "\n(2)" + frases[3] + "\n(3)" + 
        frases[4] + "\n(4)" + frases[5]);
        int escolha = sc.nextInt();
        return escolha;
    }

    public int inicio(){
        System.out.println(frases);
        int escolha = 0;
        return escolha;
    }
}
